#!/bin/bash
set -e
echo customization-helloworld-prebuilt-deb-1
